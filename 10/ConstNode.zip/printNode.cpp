#include <ConstNode.h>


int main(){

  ConstNode *cnode = new ConstNode();
  cnode->getNode()->print();
}
